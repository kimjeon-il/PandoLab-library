// Generated product identity.
globalThis.PANDOLAB_BUILD_META = Object.freeze({
  "appVersion": "0.36.0",
  "buildId": "0.36.0-build-a8a744857856",
  "assetRevision": "0.36.0-build-a8a744857856",
  "dataRevision": "data-0da69754dc2b1878e0149a51e3188f13",
  "sourceCommit": "a8a744857856dcc9dac9332c0e47f53c29192af5",
  "dataCommit": "11a5fe6132dc36a13cc81bc0a93f0ba0d9ed9cd5",
  "mapProject": {
    "format": "pandolab-map-project-manifest",
    "schemaVersion": 1,
    "projectId": "default-world",
    "documentFormat": "pandolab-project-state",
    "resources": {
      "world": {
        "catalog": "assets/data/world/current.json"
      },
      "territorial": {
        "catalog": "assets/data/builtin-world/generated/v1/index.json"
      },
      "rivers": {
        "catalog": "assets/data/hydro/v0.13.4/manifest.json"
      },
      "lakes": {
        "catalog": "assets/data/hydro/v0.13.4/manifest.json"
      },
      "places": {
        "catalog": "assets/data/places/manifest.json"
      },
      "placeLifetimes": {
        "catalog": "assets/data/places/urban-lifetimes-v1.json"
      },
      "terrain": {
        "catalog": "assets/data/terrain-preview/v0.13.3-p2/manifest.json"
      },
      "physicalLand": {
        "catalog": "assets/data/physical-land/v1/manifest.json"
      },
      "preparedMeshes": {
        "catalog": "assets/data/prepared-polygons/generated/v2/manifest.json"
      }
    }
  },
  "mapProjectManifest": {
    "url": "assets/data/projects/default-world/manifest.json",
    "encoding": "identity",
    "compressedBytes": 963,
    "decodedBytes": 963,
    "sha256": "4b736f271773c12163804dbec84c2140df7d0569aaba2ca1bc73553559f213fd"
  },
  "worldBundle": {
    "url": "assets/data/world/current.json",
    "encoding": "identity",
    "compressedBytes": 89466,
    "decodedBytes": 89466,
    "sha256": "9fe20b2cf9ae18ad984e4547d9424fd74dc92fea4f7829f2056c24ad211a24a0"
  },
  "builtinWorld": {
    "url": "assets/data/builtin-world/generated/v1/index.json",
    "encoding": "identity",
    "compressedBytes": 2013521,
    "decodedBytes": 2013521,
    "sha256": "e26aff18bc65538e7a2bbafafd407a497cd891e1f7ec83e926fd0151aed426de"
  },
  "preparedPolygonMeshes": {
    "url": "assets/data/prepared-polygons/generated/v2/manifest.json",
    "encoding": "identity",
    "compressedBytes": 339413,
    "decodedBytes": 339413,
    "sha256": "49b13b733735309cb3444a27dd0d4c0a8c0915123fa38084ce66d19e80d89884",
    "algorithmSourceSha256": "124e8a38ce8f67bf6062ef07f2ae6b1c8588c97f1e64e060a9c774f05dcd2abc"
  },
  "workerAssets": {
    "assets/js/workers/canvas-render-worker.js": {
      "url": "assets/worker-runtime/db211a3cfe33776519fec2fe9449c749/assets/js/workers/canvas-render-worker.js",
      "files": [
        "assets/worker-runtime/db211a3cfe33776519fec2fe9449c749/assets/js/modules/terrain-manifest.js",
        "assets/worker-runtime/db211a3cfe33776519fec2fe9449c749/assets/js/vendor/d3.min.js",
        "assets/worker-runtime/db211a3cfe33776519fec2fe9449c749/assets/js/workers/canvas-render-worker.js",
        "assets/worker-runtime/db211a3cfe33776519fec2fe9449c749/assets/js/workers/canvas-scene-composition-core.js",
        "assets/worker-runtime/db211a3cfe33776519fec2fe9449c749/assets/js/workers/canvas-terrain-dem-core.js",
        "assets/worker-runtime/db211a3cfe33776519fec2fe9449c749/assets/js/workers/geographic-boundary-core.js",
        "assets/worker-runtime/db211a3cfe33776519fec2fe9449c749/assets/js/workers/resource-update-policy-core.js",
        "assets/worker-runtime/db211a3cfe33776519fec2fe9449c749/assets/js/workers/terrain-tile-selection-core.js"
      ],
      "sha256": {
        "assets/worker-runtime/db211a3cfe33776519fec2fe9449c749/assets/js/modules/terrain-manifest.js": "84db9b3fe1d4e58c339c06e02f65f863c51dadfbe08c9af17589c127ec355e46",
        "assets/worker-runtime/db211a3cfe33776519fec2fe9449c749/assets/js/vendor/d3.min.js": "4cdf92091ed0cfdd8b862af1c6d4744bd0458e746b92c1bbd5403a1143ecd538",
        "assets/worker-runtime/db211a3cfe33776519fec2fe9449c749/assets/js/workers/canvas-render-worker.js": "2b62e38a8ac63f2685c94753f51a17e6e73924fd1106f03180a7cc998f224c46",
        "assets/worker-runtime/db211a3cfe33776519fec2fe9449c749/assets/js/workers/canvas-scene-composition-core.js": "36d94198654902369c51bb96cae01be0f5bd44b401f6e2f1a4eaf22e9fe9aa00",
        "assets/worker-runtime/db211a3cfe33776519fec2fe9449c749/assets/js/workers/canvas-terrain-dem-core.js": "27ddfb74030756189c588ca5e1d1b529d4ea708e809c51568f32357bcad17a3d",
        "assets/worker-runtime/db211a3cfe33776519fec2fe9449c749/assets/js/workers/geographic-boundary-core.js": "b9017382fcc828924608c8a32ddbf2831800475a725b432cad9e6445d33bc8ea",
        "assets/worker-runtime/db211a3cfe33776519fec2fe9449c749/assets/js/workers/resource-update-policy-core.js": "58be87ea6451216f1456fe99d2d36dabecd3188484ee456c603f79506c8c9d03",
        "assets/worker-runtime/db211a3cfe33776519fec2fe9449c749/assets/js/workers/terrain-tile-selection-core.js": "c85e13a1a33905f795d44db87879f7a88849eadcc786c8580da1065893ef6346"
      }
    },
    "assets/js/workers/core-viewer-session-worker.js": {
      "url": "assets/worker-runtime/0e333e00986515b6f30df6015169b72c/assets/js/workers/core-viewer-session-worker.js",
      "files": [
        "assets/worker-runtime/0e333e00986515b6f30df6015169b72c/assets/js/modules/core-document-runtime.js",
        "assets/worker-runtime/0e333e00986515b6f30df6015169b72c/assets/js/modules/core-wasm-loader.js",
        "assets/worker-runtime/0e333e00986515b6f30df6015169b72c/assets/js/modules/core-worker-runtime.js",
        "assets/worker-runtime/0e333e00986515b6f30df6015169b72c/assets/js/modules/country-flags.js",
        "assets/worker-runtime/0e333e00986515b6f30df6015169b72c/assets/js/modules/product-mode-policy.js",
        "assets/worker-runtime/0e333e00986515b6f30df6015169b72c/assets/js/modules/reliability-core.js",
        "assets/worker-runtime/0e333e00986515b6f30df6015169b72c/assets/js/modules/stored-asset-loader.js",
        "assets/worker-runtime/0e333e00986515b6f30df6015169b72c/assets/js/workers/core-viewer-session-worker.js",
        "assets/worker-runtime/0e333e00986515b6f30df6015169b72c/assets/js/workers/worker-rpc-host.js"
      ],
      "sha256": {
        "assets/worker-runtime/0e333e00986515b6f30df6015169b72c/assets/js/modules/core-document-runtime.js": "86a561358e573a35b4c8e2fefeacdb3d79e729946416bfae4895974fc419f147",
        "assets/worker-runtime/0e333e00986515b6f30df6015169b72c/assets/js/modules/core-wasm-loader.js": "5a36f5c1e9fb3f41ced4e29c796d82bbb68548f5e8773e59226b7cdb89d68d72",
        "assets/worker-runtime/0e333e00986515b6f30df6015169b72c/assets/js/modules/core-worker-runtime.js": "525ac3a1ed857f1e63edd7f73121e67ab34939eb39c94fad899264bd8feef9c2",
        "assets/worker-runtime/0e333e00986515b6f30df6015169b72c/assets/js/modules/country-flags.js": "fc63e259d6051f63a554fd188083dd952b4b50e52d6b5c7a65300001cedebb8a",
        "assets/worker-runtime/0e333e00986515b6f30df6015169b72c/assets/js/modules/product-mode-policy.js": "9024b4361549d946f7953294bdbe3b359bc363b1dd3d004c990a60e561535cd1",
        "assets/worker-runtime/0e333e00986515b6f30df6015169b72c/assets/js/modules/reliability-core.js": "88f64cc6fbece517d9280fb64a591628aa51eda38e46793db3455340e76d3bc0",
        "assets/worker-runtime/0e333e00986515b6f30df6015169b72c/assets/js/modules/stored-asset-loader.js": "691dc9bef72cede17f3940529cd631b382fea2f41c60cdb2e92f0e2e780508a6",
        "assets/worker-runtime/0e333e00986515b6f30df6015169b72c/assets/js/workers/core-viewer-session-worker.js": "c2533dbc22d3cd35a44ff5afd5f704fb4acfcba9634c0b6ccb93e5884d8d718f",
        "assets/worker-runtime/0e333e00986515b6f30df6015169b72c/assets/js/workers/worker-rpc-host.js": "a9235d322b41e77726635733f09c15b4d03ba8c94f53e06fb504c7dd27b3b6da"
      }
    },
    "assets/js/workers/country-shared-boundary-worker.js": {
      "url": "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/workers/country-shared-boundary-worker.js",
      "files": [
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/boundary-spatial-index.js",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/boundary-topology.js",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/coordinate-bounds.js",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/core-wasm-loader.js",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/country-contact-core.js",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/country-contact-row-pruning.js",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/country-shared-boundary-cache.js",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/country-shared-boundary-packet.js",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/country-stroke-group-reuse.js",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/geographic-boundary.js",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/gpu-stroke-geometry.js",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/map-edit-geometry.js",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/polygon-geometry.js",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/polygon-mesh-codec.js",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/prepared-mesh-delta.js",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/prepared-polygon-mesh.js",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/reliability-core.js",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/stored-asset-loader.js",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/temporal.js",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/territorial-units.js",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/workers/country-shared-boundary-worker.js",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/workers/polygon-raster-contract.js"
      ],
      "sha256": {
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/boundary-spatial-index.js": "9fe554b8c32276fe9aa5d11416ef052531e280b59f199f468488b2940f23bbee",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/boundary-topology.js": "02310706dcac0cf42408ff98bfa77c024027a27db2ae5b556580d3962ed98d9d",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/coordinate-bounds.js": "67e2598e59d6e5ff98d871566332286dc83d7e4f9fbc3dc1236c9cc9d08665e0",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/core-wasm-loader.js": "5a36f5c1e9fb3f41ced4e29c796d82bbb68548f5e8773e59226b7cdb89d68d72",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/country-contact-core.js": "c2fb3c9ef329e1c6cefcee2a513175ef03e6e1f3bdebb293bda7630580680472",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/country-contact-row-pruning.js": "1e617d972676a308c92b0a869bf488cc55d9c249e3e3114a53964ed90171363d",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/country-shared-boundary-cache.js": "f4d0d32a5b2a6f22df0cc2652c2cbccb6ee3cb89311f91a04039d37bd394c250",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/country-shared-boundary-packet.js": "f4a0225ca28dd6c5bd9b9fdb2dac8161c3f2586378298170bd371fc54fa188b1",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/country-stroke-group-reuse.js": "f23908df18e2801ea991bd99416cdbb83054722d519ea309ce1cfdb222b9daaa",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/geographic-boundary.js": "e5df7ab85b1a8e93745e22a02c47e2c807b159242a3b7fea894372f0bcf85170",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/gpu-stroke-geometry.js": "c7b885a4150c20f957b2477e48d03763e9778be728afc0481016e9b44e5e05fe",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/map-edit-geometry.js": "01a51792ffbd890ac66ce7628cbe661309a6bf409e1f91b07411499d398e88ea",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/polygon-geometry.js": "462d09631ed28ab48efb227405143e159d17cd0f9dd764511a0a636c67b90d74",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/polygon-mesh-codec.js": "c6ef9862abd776a46e2a4c4707f270e61f023539b71e7a9c7fcfc6519e9b130c",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/prepared-mesh-delta.js": "9e706fc8a63be6638e7bcb5523d17cb34e790e7d4da42867b369c63b72b7f26a",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/prepared-polygon-mesh.js": "c86e6d168c8adbbe9d18572361afa6c4afdb1c961c1824fad052d63a6ee9c4de",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/reliability-core.js": "88f64cc6fbece517d9280fb64a591628aa51eda38e46793db3455340e76d3bc0",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/stored-asset-loader.js": "691dc9bef72cede17f3940529cd631b382fea2f41c60cdb2e92f0e2e780508a6",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/temporal.js": "7901600b49382764c0b4838d7df678e6e00830da9956edea20fe8cb593791953",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/modules/territorial-units.js": "a76fb89adab9788f6e690694b4102680b5e2bb7c24b4fa428750176c9061ad80",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/workers/country-shared-boundary-worker.js": "85f42c4cba88adfc1dd4ac943d5b2fe4dbb3921491df55e0bd36bf26ddc0558e",
        "assets/worker-runtime/8425b6aa42bac05c669758f49ca1b519/assets/js/workers/polygon-raster-contract.js": "c6cf8183f68dd73898655718f842bd2170afe57bbf4269c2166bb16dbcd35d61"
      }
    },
    "assets/js/workers/data-loader-worker.js": {
      "url": "assets/worker-runtime/8b3a3514b7b5e709cef1c8abfac746d7/assets/js/workers/data-loader-worker.js",
      "files": [
        "assets/worker-runtime/8b3a3514b7b5e709cef1c8abfac746d7/assets/js/modules/canonical-country-packet.js",
        "assets/worker-runtime/8b3a3514b7b5e709cef1c8abfac746d7/assets/js/modules/country-mesh-codec.js",
        "assets/worker-runtime/8b3a3514b7b5e709cef1c8abfac746d7/assets/js/modules/country-stroke-preparation.js",
        "assets/worker-runtime/8b3a3514b7b5e709cef1c8abfac746d7/assets/js/modules/gpu-stroke-geometry.js",
        "assets/worker-runtime/8b3a3514b7b5e709cef1c8abfac746d7/assets/js/modules/mesh-spatial-blocks.js",
        "assets/worker-runtime/8b3a3514b7b5e709cef1c8abfac746d7/assets/js/modules/reliability-core.js",
        "assets/worker-runtime/8b3a3514b7b5e709cef1c8abfac746d7/assets/js/modules/startup-readiness.js",
        "assets/worker-runtime/8b3a3514b7b5e709cef1c8abfac746d7/assets/js/modules/stored-asset-loader.js",
        "assets/worker-runtime/8b3a3514b7b5e709cef1c8abfac746d7/assets/js/modules/worker-asset-url.js",
        "assets/worker-runtime/8b3a3514b7b5e709cef1c8abfac746d7/assets/js/modules/world-bundle-manifest.js",
        "assets/worker-runtime/8b3a3514b7b5e709cef1c8abfac746d7/assets/js/workers/data-loader-worker.js"
      ],
      "sha256": {
        "assets/worker-runtime/8b3a3514b7b5e709cef1c8abfac746d7/assets/js/modules/canonical-country-packet.js": "ecf6f8c1c94b861cda69df9feacd944b55112a39f239eced36a8e9dccd01768d",
        "assets/worker-runtime/8b3a3514b7b5e709cef1c8abfac746d7/assets/js/modules/country-mesh-codec.js": "ce923dc5cd6254406fa3cb91e171ecfc51a3151b65311161b039fa2c1e20287e",
        "assets/worker-runtime/8b3a3514b7b5e709cef1c8abfac746d7/assets/js/modules/country-stroke-preparation.js": "9d54d24ac22d02d8507638b488f17f3d54b15775fdf877f737e894e996b08de1",
        "assets/worker-runtime/8b3a3514b7b5e709cef1c8abfac746d7/assets/js/modules/gpu-stroke-geometry.js": "c7b885a4150c20f957b2477e48d03763e9778be728afc0481016e9b44e5e05fe",
        "assets/worker-runtime/8b3a3514b7b5e709cef1c8abfac746d7/assets/js/modules/mesh-spatial-blocks.js": "f578d77daca385afe0d00bf105e9e85cfb208d77c8090cd2141ed0c6d76308b3",
        "assets/worker-runtime/8b3a3514b7b5e709cef1c8abfac746d7/assets/js/modules/reliability-core.js": "88f64cc6fbece517d9280fb64a591628aa51eda38e46793db3455340e76d3bc0",
        "assets/worker-runtime/8b3a3514b7b5e709cef1c8abfac746d7/assets/js/modules/startup-readiness.js": "e851c5e71fc26fb4b85eb246a999edb58f36a63540f93cb762a25dfb7dd37970",
        "assets/worker-runtime/8b3a3514b7b5e709cef1c8abfac746d7/assets/js/modules/stored-asset-loader.js": "691dc9bef72cede17f3940529cd631b382fea2f41c60cdb2e92f0e2e780508a6",
        "assets/worker-runtime/8b3a3514b7b5e709cef1c8abfac746d7/assets/js/modules/worker-asset-url.js": "7d1c6cf9781e3df0fa3e561c00dc373f3a04a5cb0390268170ffac5590d9a9b4",
        "assets/worker-runtime/8b3a3514b7b5e709cef1c8abfac746d7/assets/js/modules/world-bundle-manifest.js": "78924e776c5fef3d2b73caa5b017aa87b2e76ce6f0da213ab4bbaf18091ed953",
        "assets/worker-runtime/8b3a3514b7b5e709cef1c8abfac746d7/assets/js/workers/data-loader-worker.js": "2d15e74cbee6fac7b5224b413972164ad8e4a77358f7e71e3a9f02b9930e580c"
      }
    },
    "assets/js/workers/gpu-mesh-worker.js": {
      "url": "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/workers/gpu-mesh-worker.js",
      "files": [
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/modules/core-wasm-loader.js",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/modules/country-mesh-preparation.js",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/modules/country-mesh-transfer.js",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/modules/country-stroke-preparation.js",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/modules/gpu-stroke-geometry.js",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/modules/mesh-spatial-blocks.js",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/modules/polygon-mesh-codec.js",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/modules/prepared-mesh-delta.js",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/modules/prepared-polygon-mesh.js",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/modules/reliability-core.js",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/modules/stored-asset-loader.js",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/modules/temporal.js",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/modules/worker-asset-url.js",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/workers/geographic-boundary-core.js",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/workers/gpu-mesh-core.js",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/workers/gpu-mesh-worker.js",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/workers/polygon-raster-contract.js",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/workers/worker-rpc-host.js"
      ],
      "sha256": {
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/modules/core-wasm-loader.js": "5a36f5c1e9fb3f41ced4e29c796d82bbb68548f5e8773e59226b7cdb89d68d72",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/modules/country-mesh-preparation.js": "66702428dd1cfb1e402d9e953a45a69b663b384114ea3babdaaa2bfdb9ec5826",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/modules/country-mesh-transfer.js": "e7f3430729d4f1f9da52f69a9a5cfca829e6bba9a0cbb9d829e6a68e0f3e2503",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/modules/country-stroke-preparation.js": "9d54d24ac22d02d8507638b488f17f3d54b15775fdf877f737e894e996b08de1",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/modules/gpu-stroke-geometry.js": "c7b885a4150c20f957b2477e48d03763e9778be728afc0481016e9b44e5e05fe",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/modules/mesh-spatial-blocks.js": "f578d77daca385afe0d00bf105e9e85cfb208d77c8090cd2141ed0c6d76308b3",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/modules/polygon-mesh-codec.js": "c6ef9862abd776a46e2a4c4707f270e61f023539b71e7a9c7fcfc6519e9b130c",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/modules/prepared-mesh-delta.js": "9e706fc8a63be6638e7bcb5523d17cb34e790e7d4da42867b369c63b72b7f26a",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/modules/prepared-polygon-mesh.js": "c86e6d168c8adbbe9d18572361afa6c4afdb1c961c1824fad052d63a6ee9c4de",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/modules/reliability-core.js": "88f64cc6fbece517d9280fb64a591628aa51eda38e46793db3455340e76d3bc0",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/modules/stored-asset-loader.js": "691dc9bef72cede17f3940529cd631b382fea2f41c60cdb2e92f0e2e780508a6",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/modules/temporal.js": "7901600b49382764c0b4838d7df678e6e00830da9956edea20fe8cb593791953",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/modules/worker-asset-url.js": "7d1c6cf9781e3df0fa3e561c00dc373f3a04a5cb0390268170ffac5590d9a9b4",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/workers/geographic-boundary-core.js": "b9017382fcc828924608c8a32ddbf2831800475a725b432cad9e6445d33bc8ea",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/workers/gpu-mesh-core.js": "97463d0dc334c6e93187a4af998c4d13fbed93ef96c3e3de32108acce3270fe2",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/workers/gpu-mesh-worker.js": "ca21d0c56a3cde17696590514d7d03b2a422a80c874ed906a9209c99b19878eb",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/workers/polygon-raster-contract.js": "c6cf8183f68dd73898655718f842bd2170afe57bbf4269c2166bb16dbcd35d61",
        "assets/worker-runtime/3dddbc213b479feb3f1412a24c03efd0/assets/js/workers/worker-rpc-host.js": "a9235d322b41e77726635733f09c15b4d03ba8c94f53e06fb504c7dd27b3b6da"
      }
    },
    "assets/js/workers/hydro-tile-worker.js": {
      "url": "assets/worker-runtime/60d86368791f4a812932a390bd26fc6d/assets/js/workers/hydro-tile-worker.js",
      "files": [
        "assets/worker-runtime/60d86368791f4a812932a390bd26fc6d/assets/js/vendor/earcut.min.js",
        "assets/worker-runtime/60d86368791f4a812932a390bd26fc6d/assets/js/vendor/fflate/fflate.min.js",
        "assets/worker-runtime/60d86368791f4a812932a390bd26fc6d/assets/js/workers/geographic-boundary-core.js",
        "assets/worker-runtime/60d86368791f4a812932a390bd26fc6d/assets/js/workers/hydro-shard-store.js",
        "assets/worker-runtime/60d86368791f4a812932a390bd26fc6d/assets/js/workers/hydro-tile-worker.js"
      ],
      "sha256": {
        "assets/worker-runtime/60d86368791f4a812932a390bd26fc6d/assets/js/vendor/earcut.min.js": "1444195270d4358ef8dd1a448074f555d7ac3c83c850f5648b611ea1d2090ff3",
        "assets/worker-runtime/60d86368791f4a812932a390bd26fc6d/assets/js/vendor/fflate/fflate.min.js": "86d12f1b80ed5c9476ea213fbbfddee5fa6366caf6b2c1ea1c8d1f3fdec9fafc",
        "assets/worker-runtime/60d86368791f4a812932a390bd26fc6d/assets/js/workers/geographic-boundary-core.js": "b9017382fcc828924608c8a32ddbf2831800475a725b432cad9e6445d33bc8ea",
        "assets/worker-runtime/60d86368791f4a812932a390bd26fc6d/assets/js/workers/hydro-shard-store.js": "e890b435eab59d6e3eb28585a2a3d49eb5decd4690fadddce3754b930eb36f6e",
        "assets/worker-runtime/60d86368791f4a812932a390bd26fc6d/assets/js/workers/hydro-tile-worker.js": "5fe68ebd1b7e502b441a43295c2e783a35a421088b54e429a998dbd61bac2e16"
      }
    },
    "assets/js/workers/label-anchor-worker.js": {
      "url": "assets/worker-runtime/c2925735b137f3b672ae83414499cb0d/assets/js/workers/label-anchor-worker.js",
      "files": [
        "assets/worker-runtime/c2925735b137f3b672ae83414499cb0d/assets/js/vendor/d3.min.js",
        "assets/worker-runtime/c2925735b137f3b672ae83414499cb0d/assets/js/workers/label-anchor-worker.js"
      ],
      "sha256": {
        "assets/worker-runtime/c2925735b137f3b672ae83414499cb0d/assets/js/vendor/d3.min.js": "4cdf92091ed0cfdd8b862af1c6d4744bd0458e746b92c1bbd5403a1143ecd538",
        "assets/worker-runtime/c2925735b137f3b672ae83414499cb0d/assets/js/workers/label-anchor-worker.js": "cd3c083504c61b8cd6daecb9b4e4c4cab4e0d8848315871442e474d938a2073a"
      }
    },
    "assets/js/workers/map-display-worker.js": {
      "url": "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/workers/map-display-worker.js",
      "files": [
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/boundary-lines.js",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/boundary-spatial-index.js",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/boundary-topology.js",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/coordinate-bounds.js",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/core-wasm-loader.js",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/country-contact-core.js",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/country-contact-row-pruning.js",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/country-shared-boundary-cache.js",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/geographic-boundary.js",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/geometry-versions.js",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/map-display-preparation.js",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/map-edit-geometry.js",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/polygon-clipping-core.js",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/polygon-geometry.js",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/reliability-core.js",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/stored-asset-loader.js",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/temporal.js",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/territorial-highlight-boundary.js",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/territorial-units.js",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/workers/map-display-worker.js",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/workers/worker-rpc-host.js"
      ],
      "sha256": {
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/boundary-lines.js": "f831f18cc622677a284a7934efb9d961a6da212e8ffed9b7c0053b881e0a5e1d",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/boundary-spatial-index.js": "9fe554b8c32276fe9aa5d11416ef052531e280b59f199f468488b2940f23bbee",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/boundary-topology.js": "02310706dcac0cf42408ff98bfa77c024027a27db2ae5b556580d3962ed98d9d",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/coordinate-bounds.js": "67e2598e59d6e5ff98d871566332286dc83d7e4f9fbc3dc1236c9cc9d08665e0",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/core-wasm-loader.js": "5a36f5c1e9fb3f41ced4e29c796d82bbb68548f5e8773e59226b7cdb89d68d72",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/country-contact-core.js": "c2fb3c9ef329e1c6cefcee2a513175ef03e6e1f3bdebb293bda7630580680472",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/country-contact-row-pruning.js": "1e617d972676a308c92b0a869bf488cc55d9c249e3e3114a53964ed90171363d",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/country-shared-boundary-cache.js": "f4d0d32a5b2a6f22df0cc2652c2cbccb6ee3cb89311f91a04039d37bd394c250",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/geographic-boundary.js": "e5df7ab85b1a8e93745e22a02c47e2c807b159242a3b7fea894372f0bcf85170",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/geometry-versions.js": "c9f9d18ff6e154c00724d0ba118f6f57dada3e41db299edcc260414112b3eaa4",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/map-display-preparation.js": "82cff22637622bff8344b30c31ba388d98f9def0e3216abe9ed9343cb33fa149",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/map-edit-geometry.js": "01a51792ffbd890ac66ce7628cbe661309a6bf409e1f91b07411499d398e88ea",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/polygon-clipping-core.js": "cd6c3f1ef8d1b0c06285355dd556129abec537c5626dee798d6811b5d07a8356",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/polygon-geometry.js": "462d09631ed28ab48efb227405143e159d17cd0f9dd764511a0a636c67b90d74",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/reliability-core.js": "88f64cc6fbece517d9280fb64a591628aa51eda38e46793db3455340e76d3bc0",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/stored-asset-loader.js": "691dc9bef72cede17f3940529cd631b382fea2f41c60cdb2e92f0e2e780508a6",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/temporal.js": "7901600b49382764c0b4838d7df678e6e00830da9956edea20fe8cb593791953",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/territorial-highlight-boundary.js": "9e625f91e7c0c60fe4002cac570d3286efc0a445930698664961e9d1bf62898f",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/modules/territorial-units.js": "a76fb89adab9788f6e690694b4102680b5e2bb7c24b4fa428750176c9061ad80",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/workers/map-display-worker.js": "1faee9436143b913393c3eb7c19ddb5495ba91dd094344d175b8baa3c74cac87",
        "assets/worker-runtime/6829e1db976927534ee58050ccde3202/assets/js/workers/worker-rpc-host.js": "a9235d322b41e77726635733f09c15b4d03ba8c94f53e06fb504c7dd27b3b6da"
      }
    },
    "assets/js/workers/place-worker.js": {
      "url": "assets/worker-runtime/449db7d1ffe943799a53491984ffb661/assets/js/workers/place-worker.js",
      "files": [
        "assets/worker-runtime/449db7d1ffe943799a53491984ffb661/assets/js/modules/core-wasm-loader.js",
        "assets/worker-runtime/449db7d1ffe943799a53491984ffb661/assets/js/modules/hydro-tile-window.js",
        "assets/worker-runtime/449db7d1ffe943799a53491984ffb661/assets/js/modules/label-layout.js",
        "assets/worker-runtime/449db7d1ffe943799a53491984ffb661/assets/js/modules/map-visual-frame.js",
        "assets/worker-runtime/449db7d1ffe943799a53491984ffb661/assets/js/modules/place-codec.js",
        "assets/worker-runtime/449db7d1ffe943799a53491984ffb661/assets/js/modules/place-contract.js",
        "assets/worker-runtime/449db7d1ffe943799a53491984ffb661/assets/js/modules/place-name-display.js",
        "assets/worker-runtime/449db7d1ffe943799a53491984ffb661/assets/js/modules/place-worker-store.js",
        "assets/worker-runtime/449db7d1ffe943799a53491984ffb661/assets/js/modules/reliability-core.js",
        "assets/worker-runtime/449db7d1ffe943799a53491984ffb661/assets/js/modules/stored-asset-loader.js",
        "assets/worker-runtime/449db7d1ffe943799a53491984ffb661/assets/js/modules/temporal.js",
        "assets/worker-runtime/449db7d1ffe943799a53491984ffb661/assets/js/workers/place-worker.js",
        "assets/worker-runtime/449db7d1ffe943799a53491984ffb661/assets/js/workers/worker-rpc-host.js"
      ],
      "sha256": {
        "assets/worker-runtime/449db7d1ffe943799a53491984ffb661/assets/js/modules/core-wasm-loader.js": "5a36f5c1e9fb3f41ced4e29c796d82bbb68548f5e8773e59226b7cdb89d68d72",
        "assets/worker-runtime/449db7d1ffe943799a53491984ffb661/assets/js/modules/hydro-tile-window.js": "060b857eb834c3b9229ea63640d5df706d28d58f5848f9c86692f2919a5de425",
        "assets/worker-runtime/449db7d1ffe943799a53491984ffb661/assets/js/modules/label-layout.js": "a744eda3b8c87d798d90ef37c64b189501bf80a90963d637517f72637f245174",
        "assets/worker-runtime/449db7d1ffe943799a53491984ffb661/assets/js/modules/map-visual-frame.js": "6943316141713c22f452107cb1858f5b5968f74e11d68bdbebbf7db566bb498a",
        "assets/worker-runtime/449db7d1ffe943799a53491984ffb661/assets/js/modules/place-codec.js": "010afe8d13496f58d72b6e6877c858030b7e11af8cc0de1d39e95a21f992bf44",
        "assets/worker-runtime/449db7d1ffe943799a53491984ffb661/assets/js/modules/place-contract.js": "a325ce4ea6e4fe457ff463fe92245dd8d83feff984c803cc5397d43110f2d260",
        "assets/worker-runtime/449db7d1ffe943799a53491984ffb661/assets/js/modules/place-name-display.js": "c0d17c259d621195c3b8dc69c5ae595807e80012add3d9b382e93d49a6803d74",
        "assets/worker-runtime/449db7d1ffe943799a53491984ffb661/assets/js/modules/place-worker-store.js": "806723f8b15100dc63471e24c5d3a2a1abf0e8cb51cace1432f5712417f33716",
        "assets/worker-runtime/449db7d1ffe943799a53491984ffb661/assets/js/modules/reliability-core.js": "88f64cc6fbece517d9280fb64a591628aa51eda38e46793db3455340e76d3bc0",
        "assets/worker-runtime/449db7d1ffe943799a53491984ffb661/assets/js/modules/stored-asset-loader.js": "691dc9bef72cede17f3940529cd631b382fea2f41c60cdb2e92f0e2e780508a6",
        "assets/worker-runtime/449db7d1ffe943799a53491984ffb661/assets/js/modules/temporal.js": "7901600b49382764c0b4838d7df678e6e00830da9956edea20fe8cb593791953",
        "assets/worker-runtime/449db7d1ffe943799a53491984ffb661/assets/js/workers/place-worker.js": "1429bf1a1cdefa5273aa8a4600eaad7bef48480e70b7e4f74cd03943de1e9535",
        "assets/worker-runtime/449db7d1ffe943799a53491984ffb661/assets/js/workers/worker-rpc-host.js": "a9235d322b41e77726635733f09c15b4d03ba8c94f53e06fb504c7dd27b3b6da"
      }
    },
    "assets/js/workers/project-read-worker.js": {
      "url": "assets/worker-runtime/4efe46fcc90336d5bbfe760e82097e02/assets/js/workers/project-read-worker.js",
      "files": [
        "assets/worker-runtime/4efe46fcc90336d5bbfe760e82097e02/assets/js/modules/gpkg-read-core.js",
        "assets/worker-runtime/4efe46fcc90336d5bbfe760e82097e02/assets/js/vendor/sql/sql-wasm.js",
        "assets/worker-runtime/4efe46fcc90336d5bbfe760e82097e02/assets/js/workers/project-read-worker.js"
      ],
      "sha256": {
        "assets/worker-runtime/4efe46fcc90336d5bbfe760e82097e02/assets/js/modules/gpkg-read-core.js": "0eafabc20e0b32903c531845ceb1b3eb577968fbbc95df158601f0bf54852944",
        "assets/worker-runtime/4efe46fcc90336d5bbfe760e82097e02/assets/js/vendor/sql/sql-wasm.js": "f1c84000dbc856c9d87f4f3aabc4d3654bd436165db4be3da13751db3a9c20d7",
        "assets/worker-runtime/4efe46fcc90336d5bbfe760e82097e02/assets/js/workers/project-read-worker.js": "cfe8c26bd45349dc9f03abf945b537ff2385d96b6158daefe1e7e1b723854944"
      }
    }
  },
  "physicalLand": {
    "url": "assets/data/physical-land/v1/geometry.json.gz",
    "encoding": "gzip",
    "compressedBytes": 4357309,
    "decodedBytes": 12385591,
    "sha256": "aeb0905d1f95d387261c3c798aa7847d9c15fb3203858b10bfc5c21a94578f98"
  },
  "initialLandPreview": {
    "url": "assets/data/physical-land/preview/v1/26b2682f210511e10a91b9e0.json.gz",
    "encoding": "gzip",
    "compressedBytes": 816313,
    "decodedBytes": 2203392,
    "sha256": "26b2682f210511e10a91b9e01a9d3c5bca9ca2c4adeb8fa44599883a902752af",
    "sourceSha256": "aeb0905d1f95d387261c3c798aa7847d9c15fb3203858b10bfc5c21a94578f98",
    "algorithm": "physical-land-preview-v1-topo10",
    "coordinateCount": 96772,
    "sourceCoordinateCount": 548454,
    "polygonCount": 4274,
    "ringCount": 4291
  },
  "physicalWaterObjects": {
    "identities": [
      {
        "objectRef": {
          "domain": "hydroBuiltin",
          "id": "waterbody:caspian"
        },
        "entityKind": "lake",
        "name": "카스피해",
        "layerId": "lakes_base",
        "source": "NE5.1.1 modern baseline and approved near-1922 Caspian display restoration",
        "sourceId": "caspian-common-object-history"
      },
      {
        "objectRef": {
          "domain": "hydroBuiltin",
          "id": "waterbody:aral"
        },
        "entityKind": "lake",
        "name": "아랄해",
        "layerId": "lakes_base",
        "source": "Approved Aral near-1922 display reconstruction from Prasolov printed 1926 map",
        "sourceId": "prasolov-1926-aral-approved-20261026"
      }
    ],
    "timelineRecords": {
      "schemaVersion": 3,
      "lifetimes": [
        {
          "id": "life:waterbody:caspian",
          "objectRef": {
            "domain": "hydroBuiltin",
            "id": "waterbody:caspian"
          },
          "validFrom": null,
          "validTo": null
        },
        {
          "id": "life:waterbody:aral",
          "objectRef": {
            "domain": "hydroBuiltin",
            "id": "waterbody:aral"
          },
          "validFrom": null,
          "validTo": null
        }
      ],
      "geometryBindings": [
        {
          "id": "waterbody:caspian:waterbody:caspian:modern-before",
          "objectRef": {
            "domain": "hydroBuiltin",
            "id": "waterbody:caspian"
          },
          "validFrom": null,
          "validTo": "1921-12-31",
          "geometryRef": {
            "id": "waterbody:caspian:modern",
            "version": 1
          }
        },
        {
          "id": "waterbody:caspian:caspian-near1922-approved",
          "objectRef": {
            "domain": "hydroBuiltin",
            "id": "waterbody:caspian"
          },
          "validFrom": "1922-01-01",
          "validTo": "1929-12-31",
          "geometryRef": {
            "id": "waterbody:caspian:restored",
            "version": 2
          }
        },
        {
          "id": "waterbody:caspian:waterbody:caspian:modern-after",
          "objectRef": {
            "domain": "hydroBuiltin",
            "id": "waterbody:caspian"
          },
          "validFrom": "1930-01-01",
          "validTo": null,
          "geometryRef": {
            "id": "waterbody:caspian:modern",
            "version": 1
          }
        },
        {
          "id": "waterbody:aral:aral-prasolov1926-approved",
          "objectRef": {
            "domain": "hydroBuiltin",
            "id": "waterbody:aral"
          },
          "validFrom": "1922-01-01",
          "validTo": "1929-12-31",
          "geometryRef": {
            "id": "waterbody:aral:prasolov1926",
            "version": 1
          }
        }
      ],
      "propertyBindings": [],
      "parentRelations": []
    },
    "geometries": [
      {
        "geometryRef": {
          "id": "waterbody:caspian:modern",
          "version": 1
        },
        "asset": {
          "url": "assets/data/physical-land/v1/caspian-modern-water.json.gz",
          "encoding": "gzip",
          "compressedBytes": 20826,
          "decodedBytes": 57486,
          "sha256": "4d3709e31f9ce7185722ae36a0d26088bca6c93c6d3317aba3bc77999a265ed2"
        },
        "land": {
          "url": "assets/data/physical-land/v1/geometry.json.gz",
          "encoding": "gzip",
          "compressedBytes": 4357309,
          "decodedBytes": 12385591,
          "sha256": "aeb0905d1f95d387261c3c798aa7847d9c15fb3203858b10bfc5c21a94578f98"
        }
      },
      {
        "geometryRef": {
          "id": "waterbody:caspian:restored",
          "version": 2
        },
        "asset": {
          "url": "assets/data/physical-land/v1/caspian-1922-water.json.gz",
          "encoding": "gzip",
          "compressedBytes": 95159,
          "decodedBytes": 250314,
          "sha256": "b95c195e5b8ec07dd7bb6ea5bf186a0a7e79995a2e8eb03acd559e6138f847c9"
        },
        "land": {
          "url": "assets/data/physical-land/v1/caspian-aral-1922-1929-land.json.gz",
          "encoding": "gzip",
          "compressedBytes": 4360786,
          "decodedBytes": 12372371,
          "sha256": "66fa6cbb61a1358cfc64a8ae2c1f1b6afad1f82ed574f664e55668a08925f608",
          "storageLayout": "regional-land-v1",
          "base": {
            "url": "assets/data/physical-land/v1/geometry.json.gz",
            "encoding": "gzip",
            "compressedBytes": 4357309,
            "decodedBytes": 12385591,
            "sha256": "aeb0905d1f95d387261c3c798aa7847d9c15fb3203858b10bfc5c21a94578f98"
          },
          "replacement": {
            "url": "assets/data/physical-land/v1/replacements/sha256-2a1445bf8db1909a8b0b0e0e8a4b44e5df00d52d6ed4ea2a4636cd871442be51.json.gz",
            "encoding": "gzip",
            "sha256": "2a1445bf8db1909a8b0b0e0e8a4b44e5df00d52d6ed4ea2a4636cd871442be51",
            "compressedBytes": 104309,
            "decodedBytes": 256319
          },
          "contentSha256": "37d223c50432fe26346350e2774520b6c547cb6aa2f237040f3230ebb9cf6725"
        }
      },
      {
        "geometryRef": {
          "id": "waterbody:aral:prasolov1926",
          "version": 1
        },
        "asset": {
          "url": "assets/data/physical-land/v1/aral-1922-1929-water.json.gz",
          "encoding": "gzip",
          "compressedBytes": 11280,
          "decodedBytes": 25948,
          "sha256": "cc259cc8ddc43868994167a48ee9de3aa2df50b457c24f979d38e1611e708813"
        },
        "land": {
          "url": "assets/data/physical-land/v1/caspian-aral-1922-1929-land.json.gz",
          "encoding": "gzip",
          "compressedBytes": 4360786,
          "decodedBytes": 12372371,
          "sha256": "66fa6cbb61a1358cfc64a8ae2c1f1b6afad1f82ed574f664e55668a08925f608",
          "storageLayout": "regional-land-v1",
          "base": {
            "url": "assets/data/physical-land/v1/geometry.json.gz",
            "encoding": "gzip",
            "compressedBytes": 4357309,
            "decodedBytes": 12385591,
            "sha256": "aeb0905d1f95d387261c3c798aa7847d9c15fb3203858b10bfc5c21a94578f98"
          },
          "replacement": {
            "url": "assets/data/physical-land/v1/replacements/sha256-2a1445bf8db1909a8b0b0e0e8a4b44e5df00d52d6ed4ea2a4636cd871442be51.json.gz",
            "encoding": "gzip",
            "sha256": "2a1445bf8db1909a8b0b0e0e8a4b44e5df00d52d6ed4ea2a4636cd871442be51",
            "compressedBytes": 104309,
            "decodedBytes": 256319
          },
          "contentSha256": "37d223c50432fe26346350e2774520b6c547cb6aa2f237040f3230ebb9cf6725"
        },
        "replaces": [
          {
            "domain": "hydroBuiltin",
            "id": "lakes_base:1159126555"
          },
          {
            "domain": "hydroBuiltin",
            "id": "lakes_base:1729982865"
          }
        ]
      }
    ]
  }
});
